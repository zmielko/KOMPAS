from setuptools import setup, find_packages
setup(
    name="kompas",
    version="0.2.0",
    packages=find_packages(),
    scripts=["commands/align", "commands/sitecall"],
    # Project uses reStructuredText, so ensure that the docutils get
    # installed or upgraded on the target machine
    install_requires=["pandas", 'numpy', 'pyfaidx'],

    package_data={
        # If any package contains *.txt or *.rst files, include them:
        "": ["*.txt", "*.rst"],
        # And include any *.msg files found in the "hello" package, too:
        "hello": ["*.msg"],
    },

    # metadata to display on PyPI
    author="Zachery Mielko",
    author_email="mielkozachery@gmail.com",
    description="TFBS calling tool",
    keywords="Bioinformatics Genomics Binding TFBS",
    url="https://github.com/zmielko/TF-KOMPAS",   # project home page, if any
    project_urls={
        "Documentation": "https://github.com/zmielko/KOMPAS/wiki",
    },
    classifiers=[
        "License :: OSI Approved :: MIT"
    ]

)